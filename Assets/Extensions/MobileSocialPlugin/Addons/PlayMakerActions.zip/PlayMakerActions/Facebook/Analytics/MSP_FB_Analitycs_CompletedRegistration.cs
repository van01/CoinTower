﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FB_Analitycs_CompletedRegistration : FsmStateAction {

		public FsmString RegistrationMethod;
		
		public override void OnEnter() {
			SPFacebookAnalytics.CompletedRegistration(RegistrationMethod.Value);
			Finish ();
		}	
	}
}
