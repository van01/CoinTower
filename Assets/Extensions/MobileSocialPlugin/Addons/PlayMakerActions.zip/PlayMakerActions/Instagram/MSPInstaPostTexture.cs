using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Other")]
	public class MSPInstaPostTexture : FsmStateAction {
		
		public FsmString message;
		public FsmTexture texture;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			SPInstagram.instance.OnPostingCompleteAction += OnPostingCompleteAction;


			
			SPInstagram.instance.Share(texture.Value as Texture2D, message.Value);
			
		}

	

		void OnPostingCompleteAction (InstagramPostResult res) {
			SPInstagram.instance.OnPostingCompleteAction -= OnPostingCompleteAction;
			if(res == InstagramPostResult.RESULT_OK) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}

			Finish();

		}		
	
	}
}



